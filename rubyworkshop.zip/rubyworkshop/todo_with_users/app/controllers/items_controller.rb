class ItemsController < ApplicationController
  before_action :is_logged_in?

  def is_logged_in?
    if session[:user_id].nil?
      redirect_to login_path
    else
      @user = User.find(session[:user_id])
    end
  end

  def index
    @items = @user.items.where(completed: false)
  end

  def create
    item = Item.new
    item.title = params[:item][:title]
    item.completed = false
    item.user_id = @user.id

    item.save

    redirect_to items_path
  end

  def complete
    item = @user.items.find(params[:id])
    item.completed = true
    item.save

    redirect_to items_path
  end

  def new
  end
  
end
