class UsersController < ApplicationController
  def new
  end

  def create
    user = User.new
    user.name = params[:user][:name]
    user.email = params[:user][:email]
    user.password = params[:user][:password]
    user.password_confirmation = params[:user][:password]

    user.save
    redirect_to login_path
  end

  def login
  end

  def login_post
    user = User.find_by(email: params[:user][:email])
    if user.nil? or !user.authenticate(params[:user][:password])
      redirect_to login_path
      return
    end

    session[:user_id] = user.id
    redirect_to items_path
  end
end
