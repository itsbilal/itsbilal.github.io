Rails.application.routes.draw do
  get 'users/new', to: 'users#new', as: 'signup'
  post 'users/new', to: 'users#create'
  get 'users/login', to: 'users#login', as: 'login'
  post 'users/login', to: 'users#login_post'

  resources :items
  get 'items/:id/complete', to: 'items#complete', as: 'complete_item'

  root 'items#index'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
