class ItemsController < ApplicationController
  def index
    @items = Item.where(completed: false)
  end

  def create
    item = Item.new
    item.title = params[:item][:title]
    item.completed = false
    item.save

    redirect_to items_path
  end

  def complete
    item = Item.find(params[:id])
    item.completed = true
    item.save

    redirect_to items_path
  end

  def new
  end
end
