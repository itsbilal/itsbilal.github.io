class Item < ApplicationRecord
end
